import * as THREE from 'three';
import './style.css';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x82909a);
scene.fog = new THREE.Fog(0x82909a, 18, 65);
const camera = new THREE.PerspectiveCamera(60, innerWidth/innerHeight, .1, 120);
const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.7));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xc9d9e8,0x47382d,2.0));
const sun = new THREE.DirectionalLight(0xffe2b5,2.4);
sun.position.set(-8,16,8); sun.castShadow=true; sun.shadow.mapSize.set(1024,1024); scene.add(sun);

const mat=(color,roughness=.85)=>new THREE.MeshStandardMaterial({color,roughness});
const stone=mat(0x77756c), darkStone=mat(0x454b4c), gold=mat(0xb88c4c,.55);
const ground=new THREE.Mesh(new THREE.PlaneGeometry(100,100),mat(0x55564d));
ground.rotation.x=-Math.PI/2; ground.receiveShadow=true; scene.add(ground);

// Ancient ruin floor and pillars
for(let i=-4;i<=4;i++){
  const tile=new THREE.Mesh(new THREE.BoxGeometry(3.7,.18,3.7),mat(i%2?0x68665e:0x77746a));
  tile.position.set(i*3.8,.02,-5); tile.receiveShadow=true; scene.add(tile);
}
for(const x of [-9,9]){
  for(const z of [-12,-5,2]){
    const p=new THREE.Mesh(new THREE.CylinderGeometry(.55,.72,5,8),stone);
    p.position.set(x,2.5,z); p.castShadow=true; p.receiveShadow=true; scene.add(p);
    const cap=new THREE.Mesh(new THREE.BoxGeometry(1.5,.35,1.5),gold);
    cap.position.set(x,5.05,z); scene.add(cap);
  }
}
for(let i=0;i<16;i++){
  const rock=new THREE.Mesh(new THREE.DodecahedronGeometry(.6+Math.random()*.9,0),darkStone);
  rock.position.set((Math.random()-.5)*28,.35,(Math.random()-.5)*34-3);
  rock.rotation.set(Math.random(),Math.random(),Math.random()); rock.castShadow=true; scene.add(rock);
}

// Hero: stylized original armored guardian
const hero=new THREE.Group(); scene.add(hero);
const body=new THREE.Mesh(new THREE.CapsuleGeometry(.48,.9,4,8),mat(0x52616a));
body.position.y=1.25; body.castShadow=true; hero.add(body);
const chest=new THREE.Mesh(new THREE.BoxGeometry(.95,.62,.48),mat(0x8a8d87));
chest.position.set(0,1.55,0); chest.castShadow=true; hero.add(chest);
const head=new THREE.Mesh(new THREE.SphereGeometry(.32,16,12),mat(0xc49b76));
head.position.y=2.18; head.castShadow=true; hero.add(head);
const helmet=new THREE.Mesh(new THREE.SphereGeometry(.37,12,8,0,Math.PI*2,0,Math.PI*.55),gold);
helmet.position.y=2.3; helmet.castShadow=true; hero.add(helmet);
const cape=new THREE.Mesh(new THREE.BoxGeometry(.85,1.15,.12),mat(0x713b32));
cape.position.set(0,1.35,.36); hero.add(cape);
const weapon=new THREE.Group(); hero.add(weapon); weapon.position.set(.62,1.35,-.05);
const handle=new THREE.Mesh(new THREE.CylinderGeometry(.055,.07,.8,8),mat(0x38251d)); handle.rotation.z=-.25; weapon.add(handle);
const blade=new THREE.Mesh(new THREE.BoxGeometry(.16,1.15,.09),mat(0xc8d1d2,.3)); blade.position.set(.12,.75,0); blade.rotation.z=-.25; weapon.add(blade);
hero.position.set(0,0,7);

// Enemy builder
const enemies=[];
function makeEnemy(x,z){
 const g=new THREE.Group();
 const skin=mat(0x526e68), glow=new THREE.MeshStandardMaterial({color:0xe6a24b,emissive:0x7b3210,emissiveIntensity:1.3});
 const torso=new THREE.Mesh(new THREE.DodecahedronGeometry(.72,1),skin); torso.position.y=1.05; torso.castShadow=true; g.add(torso);
 const head2=new THREE.Mesh(new THREE.SphereGeometry(.42,12,10),skin); head2.position.y=1.95; head2.castShadow=true; g.add(head2);
 for(const sx of [-.18,.18]){const eye=new THREE.Mesh(new THREE.SphereGeometry(.07,8,8),glow);eye.position.set(sx,2,.36);g.add(eye)}
 for(const sx of [-.9,.9]){const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.2,.65,3,6),skin);arm.position.set(sx,1.1,0);arm.rotation.z=sx*.25;g.add(arm)}
 g.position.set(x,0,z); scene.add(g);
 enemies.push({group:g,hp:3,hit:0,attack:0});
}
makeEnemy(-4,-7); makeEnemy(4,-11); makeEnemy(0,-17);

const keys={}; addEventListener('keydown',e=>{keys[e.code]=true;if(e.code==='Space')e.preventDefault()});
addEventListener('keyup',e=>keys[e.code]=false);
let joy={x:0,y:0}, attacking=0, dodging=0, health=100, kills=0;
const attackBtn=document.querySelector('#attack'), dodgeBtn=document.querySelector('#dodge');
function pressAttack(e){e.preventDefault();attacking=.28}
function pressDodge(e){e.preventDefault();dodging=.32}
attackBtn.addEventListener('pointerdown',pressAttack); dodgeBtn.addEventListener('pointerdown',pressDodge);
addEventListener('keydown',e=>{if(e.code==='Space')attacking=.28;if(e.code==='ShiftLeft'||e.code==='ShiftRight')dodging=.32});

const joyEl=document.querySelector('#joystick'), stick=document.querySelector('#stick');
let joyId=null;
joyEl.addEventListener('pointerdown',e=>{joyId=e.pointerId;joyEl.setPointerCapture(joyId);updateJoy(e)});
joyEl.addEventListener('pointermove',e=>{if(e.pointerId===joyId)updateJoy(e)});
function updateJoy(e){const r=joyEl.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),m=Math.min(35,Math.hypot(dx,dy)),a=Math.atan2(dy,dx);joy.x=Math.cos(a)*m/35;joy.y=Math.sin(a)*m/35;stick.style.transform=`translate(${joy.x*35}px,${joy.y*35}px)`}
function endJoy(e){if(e.pointerId===joyId){joyId=null;joy={x:0,y:0};stick.style.transform='translate(0,0)'}}
joyEl.addEventListener('pointerup',endJoy);joyEl.addEventListener('pointercancel',endJoy);

const healthFill=document.querySelector('#healthFill'), status=document.querySelector('#status'), message=document.querySelector('#message');
const clock=new THREE.Clock();
let invuln=0;
function animate(){
 requestAnimationFrame(animate);
 const dt=Math.min(clock.getDelta(),.04);
 const forward=(keys.KeyW?1:0)-(keys.KeyS?1:0)-joy.y;
 const side=(keys.KeyD?1:0)-(keys.KeyA?1:0)+joy.x;
 const move=new THREE.Vector3(side,0,forward);
 if(move.length()>1)move.normalize();
 const moving=move.lengthSq()>.02;
 if(moving){
   hero.position.addScaledVector(move,dt*4.4);
   hero.rotation.y=Math.atan2(move.x,move.z);
 }
 hero.position.x=THREE.MathUtils.clamp(hero.position.x,-12,12);
 hero.position.z=THREE.MathUtils.clamp(hero.position.z,-22,12);
 if(attacking>0){
   attacking-=dt; weapon.rotation.z=-Math.sin((attacking/.28)*Math.PI)*1.7;
   if(attacking>.2){
     for(const en of enemies){if(en.hp>0 && en.group.position.distanceTo(hero.position)<2.35 && en.hit<=0){en.hp--;en.hit=.6;en.group.position.add(new THREE.Vector3(0,0,-.45));}}
   }
 } else weapon.rotation.z=THREE.MathUtils.damp(weapon.rotation.z,0,12,dt);
 if(dodging>0){dodging-=dt;hero.position.addScaledVector(move.lengthSq()?move:new THREE.Vector3(0,0,-1),dt*10);invuln=.25}
 invuln=Math.max(0,invuln-dt);
 for(const en of enemies){
   if(en.hp<=0){en.group.visible=false;continue}
   en.hit=Math.max(0,en.hit-dt); en.attack-=dt;
   const d=en.group.position.distanceTo(hero.position);
   if(d>1.55 && d<18){const dir=hero.position.clone().sub(en.group.position).setY(0).normalize();en.group.position.addScaledVector(dir,dt*1.05);en.group.rotation.y=Math.atan2(dir.x,dir.z)}
   else if(d<=1.55 && en.attack<=0 && invuln<=0){health=Math.max(0,health-8);en.attack=1.15}
   en.group.position.y=Math.sin(performance.now()*.003+en.group.position.x)*.04;
   en.group.scale.setScalar(en.hit>0?.88:1);
 }
 healthFill.style.width=health+'%';
 status.textContent=`Health ${health}% · Beasts defeated ${enemies.filter(e=>e.hp<=0).length}/${enemies.length}`;
 if(enemies.every(e=>e.hp<=0)){message.textContent='VICTORY — The ruins are safe!';}
 else if(health<=0){message.textContent='The guardian needs a moment. Refresh to try again.';}
 const target=new THREE.Vector3(hero.position.x,1.3,hero.position.z);
 const camPos=new THREE.Vector3(hero.position.x,6.2,hero.position.z+9.5);
 camera.position.lerp(camPos,.08); camera.lookAt(target);
 renderer.render(scene,camera);
}
animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
