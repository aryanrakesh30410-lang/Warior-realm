WARRIOR REALM — Android game starter project

This is an original, small 3D action-adventure prototype inspired by mythic action games.
It is not an official God of War game and does not use its characters, story, music, or assets.

WHAT'S INCLUDED
- 3D third-person arena
- Original armored guardian hero
- Fantasy creatures and simple boss-like combat loop
- Mobile joystick, Attack and Dodge buttons
- Keyboard controls for testing on PC

BUILD / TEST ON A COMPUTER
1. Install Node.js (LTS) and Android Studio.
2. Extract this ZIP.
3. Open a terminal in this folder.
4. Run: npm install
5. Run: npm run dev
   Open the local address shown by Vite to test in a browser.
6. To create the Android project, run:
   npx cap add android
   npm run build
   npx cap sync android
   npx cap open android
7. In Android Studio, wait for Gradle sync, then use Build > Build Bundle(s) / APK(s) > Build APK(s).

NOTE
An Android APK cannot be compiled directly in this chat environment. The project is prepared for building in Android Studio.
The game is an early prototype; it can be expanded with proper character models, animations, sound, levels, save system and more detailed combat.
